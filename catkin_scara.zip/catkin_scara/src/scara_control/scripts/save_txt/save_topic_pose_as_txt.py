#! /usr/bin/env python3

import rospy
from sensor_msgs.msg import JointState
from geometry_msgs.msg import Pose
import time


class SavePoses(object):

    def __init__(self):
        
        self._pose = JointState()
        # self.poses_dict = {"pose1":self._pose, "pose2":self._pose, "pose3":self._pose}
        self._pose_sub = rospy.Subscriber('/joint_states', JointState , self.sub_callback) 
        # joint_states , sensor_msgs/JointState
        # self.write_to_file()

    def sub_callback(self, msg):
        
        self._pose = msg.position
        
        print(self._pose)

        with open('poses.txt', 'w') as file:
            
            for x in range(100):
                    file.write(str(self._pose[0]) + ',' + str(self._pose[1]) + ',' + str(self._pose[2])+ '\n')
                    # file.write(str('hi' + '\n'))
            rospy.loginfo("Written all Poses to poses.txt file")
        

if __name__ == "__main__":
    rospy.init_node('spot_recorder', log_level=rospy.INFO) 
    save_spots_object = SavePoses()
    rospy.spin() # mantain the service open.
